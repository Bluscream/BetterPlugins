module.exports = require('./lib/BetterDiscord');
