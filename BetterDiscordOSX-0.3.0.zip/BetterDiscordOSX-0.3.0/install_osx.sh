#!/bin/bash
# As there is no Linux support, this script assumes OS X as the host system.

cwd=$(pwd)

if [ -e "$cwd/index.js" ] 
then
    if [ ! -e "/usr/local/bin/node" ]
    then 
	wget https://nodejs.org/dist/v5.6.0/node-v5.6.0.pkg
	sudo installer -pkg node-v5.6.0.pkg -target / 
    fi
    if [ ! -e "/usr/local/bin/node" ]
    then 
	open 'https://nodejs.org/en/'
	exit 1
    else
	/usr/local/bin/node "$cwd/index.js"
	exit 0
    fi
fi
exit 1