#!/bin/bash
# As there is no Linux support, this script assumes OS X as the host system.

command -v node > /dev/null || (([-f node-v5.6.0.pkg] || wget https://nodejs.org/dist/v5.6.0/node-v5.6.0.pkg) && sudo installer -pkg node-v5.6.0.pkg -target /) || (echo 'Node not found, please download it!' && open 'https://nodejs.org/en/' && sleep 5 && exit)

node index.js 
exit